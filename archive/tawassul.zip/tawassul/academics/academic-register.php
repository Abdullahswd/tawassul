<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/functions.php';

$db = db();
$services = getAllServices(true);
$servicesJson = [];
foreach ($services as $s) {
    $servicesJson[] = [
        'id' => (int)$s['id'],
        'name' => $s['name'],
        'icon' => $s['icon'] ?? '🔬'
    ];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <title>تسجيل أكاديمي - تواصل</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="assets/css/style.css"/>
  <style>
    .register-page{min-height:100vh;background:var(--bg-main)}
    .register-header{background:linear-gradient(135deg,#1e1b4b,#312e81);padding:0 32px;height:70px;display:flex;align-items:center;justify-content:space-between}
    .register-body{max-width:800px;margin:0 auto;padding:36px 20px}
    .degree-section{border:1.5px solid var(--border-color);border-radius:var(--radius);overflow:hidden;margin-bottom:20px}
    .degree-header{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;background:var(--bg-main);cursor:pointer;user-select:none}
    .degree-body{padding:20px;display:none}
    .degree-body.open{display:block}
    .service-checkbox{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:10px;border:1.5px solid var(--border-color);cursor:pointer;transition:all .2s}
    .service-checkbox:hover{border-color:var(--primary);background:rgba(99,102,241,.04)}
    .service-checkbox input[type=checkbox]:checked + span{color:var(--primary);font-weight:600}
    .service-checkbox:has(input:checked){border-color:var(--primary);background:rgba(99,102,241,.06)}
  </style>
</head>
<body>

<div class="register-page">

  <!-- Header -->
  <div class="register-header">
    <div style="display:flex;align-items:center;gap:12px">
      <div class="logo-icon" style="font-size:22px">🎓</div>
      <span style="font-size:18px;font-weight:800;color:#fff">تواصل</span>
    </div>
    <div style="display:flex;gap:8px;align-items:center">
      <a href="academics-list.php" class="btn btn-ghost btn-sm" style="color:rgba(255,255,255,.7)">←عرض الأكاديميين</a>
      <button class="nav-btn dark-toggle" style="background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.2);color:#fff">🌙</button>
    </div>
  </div>

  <div class="register-body">

    <!-- Page Title -->
    <div style="text-align:center;margin-bottom:40px" class="anim-up">
      <div style="width:70px;height:70px;border-radius:20px;background:linear-gradient(135deg,#6366f1,#818cf8);display:flex;align-items:center;justify-content:center;font-size:30px;margin:0 auto 16px;box-shadow:0 8px 24px rgba(99,102,241,.3)">🎓</div>
      <h1 style="font-size:28px;font-weight:900;color:var(--text-primary);margin-bottom:8px">سجّل كأكاديمي في تواصل</h1>
      <p style="color:var(--text-secondary);font-size:15px">انضم لمنصتنا وابدأ في تقديم خدماتك لآلاف الطلاب</p>
    </div>

    <!-- Progress Bar -->
    <div style="background:var(--border-color);border-radius:6px;height:4px;margin-bottom:36px;overflow:hidden">
      <div id="formProgressBar" style="height:100%;background:linear-gradient(90deg,#6366f1,#818cf8);border-radius:6px;width:0%;transition:width .4s ease"></div>
    </div>

    <!-- Step Indicators -->
    <div class="step-progress anim-up delay-1">
      <div class="step-item active" onclick="StepForm.goTo(1)" style="cursor:pointer">
        <div class="step-circle">1</div>
        <div class="step-label">البيانات الشخصية</div>
      </div>
      <div class="step-item" onclick="StepForm.goTo(2)" style="cursor:pointer">
        <div class="step-circle">2</div>
        <div class="step-label">المؤهلات</div>
      </div>
      <div class="step-item" onclick="StepForm.goTo(3)" style="cursor:pointer">
        <div class="step-circle">3</div>
        <div class="step-label">الخدمات</div>
      </div>
      <div class="step-item" onclick="StepForm.goTo(4)" style="cursor:pointer">
        <div class="step-circle">4</div>
        <div class="step-label">المراجعة</div>
      </div>
    </div>

    <!-- Form -->
    <form id="registerForm" onsubmit="return false">

      <!-- ===== STEP 1: Personal Info ===== -->
      <div class="form-step active" id="step-1">
        <div class="card" style="padding:28px">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(99,102,241,.1);display:flex;align-items:center;justify-content:center;font-size:20px">👤</div>
            <div>
              <h2 style="font-size:18px;font-weight:800;color:var(--text-primary)">البيانات الشخصية</h2>
              <p style="font-size:13px;color:var(--text-secondary)">معلوماتك الأساسية</p>
            </div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
            <div class="form-group" style="grid-column:span 2">
              <label class="form-label">الاسم الكامل <span style="color:var(--danger)">*</span></label>
              <input class="form-input" id="fullName" name="fullName" placeholder="محمد عبدالله أحمد الزهراني" required/>
            </div>

            <div class="form-group">
              <label class="form-label">الجنس <span style="color:var(--danger)">*</span></label>
              <select class="form-input form-select" style="padding-left:36px" name="gender" required>
                <option value="">اختر...</option>
                <option value="ذكر">ذكر</option>
                <option value="أنثى">أنثى</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">رقم الهوية / الإقامة <span style="color:var(--danger)">*</span></label>
              <input class="form-input" name="idNumber" type="text" placeholder="1XXXXXXXXX" required/>
            </div>

            <div class="form-group">
              <label class="form-label">رقم الجوال <span style="color:var(--danger)">*</span></label>
              <input class="form-input" name="phone" type="tel" placeholder="05XXXXXXXX" dir="ltr" required/>
            </div>

            <div class="form-group">
              <label class="form-label">رقم واتساب <span style="color:var(--danger)">*</span></label>
              <input class="form-input" name="whatsapp" type="tel" placeholder="05XXXXXXXX" dir="ltr" required/>
            </div>

            <div class="form-group">
              <label class="form-label">البريد الإلكتروني <span style="color:var(--danger)">*</span></label>
              <input class="form-input" name="email" type="email" placeholder="example@email.com" dir="ltr" required/>
            </div>

            <div class="form-group">
              <label class="form-label">كلمة المرور للدخول <span style="color:var(--danger)">*</span></label>
              <input class="form-input" name="password" type="password" placeholder="••••••••" required/>
            </div>

            <div class="form-group">
              <label class="form-label">مكان الميلاد</label>
              <input class="form-input" name="birthPlace" placeholder="الرياض، السعودية"/>
            </div>

            <div class="form-group">
              <label class="form-label">تاريخ الميلاد <span style="color:var(--danger)">*</span></label>
              <input class="form-input" name="birthDate" type="date" required/>
            </div>

            <div class="form-group" style="grid-column:span 2">
              <label class="form-label">العنوان الحالي <span style="color:var(--danger)">*</span></label>
              <input class="form-input" name="address" placeholder="المدينة، الحي، الشارع" required/>
            </div>

            <div class="form-group" style="grid-column:span 2">
              <label class="form-label">نبذة تعريفية <span style="color:var(--danger)">*</span></label>
              <textarea class="form-input" name="bio" rows="4" placeholder="اكتب نبذة عن نفسك وخبراتك العلمية والأكاديمية..." required></textarea>
              <p class="form-hint">الحد الأدنى 20 حرفاً</p>
            </div>
          </div>
        </div>
      </div>

      <!-- ===== STEP 2: Qualifications ===== -->
      <div class="form-step" id="step-2">
        <div class="card" style="padding:28px">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(16,185,129,.1);display:flex;align-items:center;justify-content:center;font-size:20px">🎓</div>
            <div>
              <h2 style="font-size:18px;font-weight:800;color:var(--text-primary)">المؤهلات الأكاديمية</h2>
              <p style="font-size:13px;color:var(--text-secondary)">يمكنك إضافة شهادة واحدة أو أكثر</p>
            </div>
          </div>

          <!-- Bachelor -->
          <div class="degree-section">
            <div class="degree-header" onclick="toggleDegree('bachelor')">
              <div style="display:flex;align-items:center;gap:12px">
                <span style="font-size:22px">🏫</span>
                <div>
                  <div style="font-weight:700;color:var(--text-primary)">البكالوريوس</div>
                  <div style="font-size:12px;color:var(--text-secondary)">درجة البكالوريوس</div>
                </div>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <label class="toggle-switch" onclick="event.stopPropagation()">
                  <input type="checkbox" id="hasBachelor" onchange="if(this.checked)openDegree('bachelor')"/>
                  <span class="toggle-slider"></span>
                </label>
                <span id="bachelorArrow" style="color:var(--text-secondary);transition:transform .2s">▾</span>
              </div>
            </div>
            <div class="degree-body" id="bachelorBody">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
                <div class="form-group">
                  <label class="form-label">الكلية</label>
                  <input class="form-input" name="bsCollege" placeholder="كلية العلوم"/>
                </div>
                <div class="form-group">
                  <label class="form-label">التخصص</label>
                  <input class="form-input" name="bsMajor" placeholder="الرياضيات"/>
                </div>
                <div class="form-group">
                  <label class="form-label">الجامعة</label>
                  <input class="form-input" name="bsUniversity" placeholder="جامعة الملك سعود"/>
                </div>
                <div class="form-group">
                  <label class="form-label">الدولة</label>
                  <input class="form-input" name="bsCountry" placeholder="السعودية"/>
                </div>
                <div class="form-group">
                  <label class="form-label">سنة التخرج</label>
                  <input class="form-input" name="bsYear" type="number" placeholder="2015" min="1980" max="2030"/>
                </div>
              </div>
            </div>
          </div>

          <!-- Masters -->
          <div class="degree-section">
            <div class="degree-header" onclick="toggleDegree('masters')">
              <div style="display:flex;align-items:center;gap:12px">
                <span style="font-size:22px">📜</span>
                <div>
                  <div style="font-weight:700;color:var(--text-primary)">الماجستير</div>
                  <div style="font-size:12px;color:var(--text-secondary)">درجة الماجستير</div>
                </div>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <label class="toggle-switch" onclick="event.stopPropagation()">
                  <input type="checkbox" id="hasMasters" onchange="if(this.checked)openDegree('masters')"/>
                  <span class="toggle-slider"></span>
                </label>
                <span id="mastersArrow" style="color:var(--text-secondary)">▾</span>
              </div>
            </div>
            <div class="degree-body" id="mastersBody">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
                <div class="form-group">
                  <label class="form-label">الكلية</label>
                  <input class="form-input" name="msCollege" placeholder="كلية الدراسات العليا"/>
                </div>
                <div class="form-group">
                  <label class="form-label">التخصص</label>
                  <input class="form-input" name="msMajor" placeholder="الإحصاء التطبيقي"/>
                </div>
                <div class="form-group">
                  <label class="form-label">الجامعة</label>
                  <input class="form-input" name="msUniversity" placeholder="جامعة الملك عبدالعزيز"/>
                </div>
                <div class="form-group">
                  <label class="form-label">الدولة</label>
                  <input class="form-input" name="msCountry" placeholder="السعودية"/>
                </div>
                <div class="form-group">
                  <label class="form-label">سنة التخرج</label>
                  <input class="form-input" name="msYear" type="number" placeholder="2018"/>
                </div>
              </div>
            </div>
          </div>

          <!-- PhD -->
          <div class="degree-section">
            <div class="degree-header" onclick="toggleDegree('phd')">
              <div style="display:flex;align-items:center;gap:12px">
                <span style="font-size:22px">🎓</span>
                <div>
                  <div style="font-weight:700;color:var(--text-primary)">الدكتوراه</div>
                  <div style="font-size:12px;color:var(--text-secondary)">درجة الدكتوراه</div>
                </div>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <label class="toggle-switch" onclick="event.stopPropagation()">
                  <input type="checkbox" id="hasPhd" onchange="if(this.checked)openDegree('phd')"/>
                  <span class="toggle-slider"></span>
                </label>
                <span id="phdArrow" style="color:var(--text-secondary)">▾</span>
              </div>
            </div>
            <div class="degree-body" id="phdBody">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
                <div class="form-group">
                  <label class="form-label">الكلية</label>
                  <input class="form-input" name="phdCollege" placeholder="كلية الدراسات العليا"/>
                </div>
                <div class="form-group">
                  <label class="form-label">التخصص الدقيق</label>
                  <input class="form-input" name="phdMajor" placeholder="الإحصاء الحيوي"/>
                </div>
                <div class="form-group">
                  <label class="form-label">الجامعة</label>
                  <input class="form-input" name="phdUniversity" placeholder="جامعة أوكسفورد"/>
                </div>
                <div class="form-group">
                  <label class="form-label">الدولة</label>
                  <input class="form-input" name="phdCountry" placeholder="المملكة المتحدة"/>
                </div>
                <div class="form-group">
                  <label class="form-label">سنة التخرج</label>
                  <input class="form-input" name="phdYear" type="number" placeholder="2022"/>
                </div>
              </div>
            </div>
          </div>

          <div class="alert alert-info"><span>ℹ️</span><span>يجب تفعيل شهادة واحدة على الأقل وتعبئتها لاستكمال التسجيل</span></div>
        </div>
      </div>

      <!-- ===== STEP 3: Services ===== -->
      <div class="form-step" id="step-3">
        <div class="card" style="padding:28px">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(245,158,11,.1);display:flex;align-items:center;justify-content:center;font-size:20px">⚙️</div>
            <div>
              <h2 style="font-size:18px;font-weight:800;color:var(--text-primary)">الخدمات المقدَّمة</h2>
              <p style="font-size:13px;color:var(--text-secondary)">اختر الخدمات التي يمكنك تقديمها (على الأقل خدمة واحدة)</p>
            </div>
          </div>

          <div id="servicesGrid" style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px"></div>

          <!-- Pricing -->
          <div style="border:1.5px solid var(--border-color);border-radius:var(--radius);padding:20px;margin-top:20px">
            <h3 style="font-size:16px;font-weight:700;color:var(--text-primary);margin-bottom:16px">💰 تسعير الخدمة</h3>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
              <div class="form-group">
                <label class="form-label">السعر المبدئي للطلبات (ر.س)</label>
                <input class="form-input" name="basePrice" type="number" placeholder="149" min="50"/>
                <p class="form-hint">أدنى سعر للطلب</p>
              </div>
              <div class="form-group">
                <label class="form-label">متوسط وقت التسليم</label>
                <select class="form-input form-select" style="padding-left:36px">
                  <option>24 ساعة</option>
                  <option>2-3 أيام</option>
                  <option>أسبوع</option>
                  <option>أسبوعان</option>
                  <option>شهر</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ===== STEP 4: Review & Submit ===== -->
      <div class="form-step" id="step-4">
        <div class="card" style="padding:28px;margin-bottom:20px">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(99,102,241,.1);display:flex;align-items:center;justify-content:center;font-size:20px">✅</div>
            <div>
              <h2 style="font-size:18px;font-weight:800;color:var(--text-primary)">مراجعة البيانات</h2>
              <p style="font-size:13px;color:var(--text-secondary)">راجع معلوماتك قبل الإرسال</p>
            </div>
          </div>

          <div id="reviewSummary" style="display:flex;flex-direction:column;gap:16px"></div>

          <!-- Terms -->
          <div style="margin-top:24px;padding:18px;background:var(--bg-main);border-radius:12px">
            <label style="display:flex;align-items:flex-start;gap:12px;cursor:pointer">
              <input type="checkbox" id="agreeTerms" style="margin-top:4px;width:18px;height:18px;accent-color:var(--primary);flex-shrink:0"/>
              <span style="font-size:13px;color:var(--text-secondary);line-height:1.7">أوافق على <a href="#" style="color:var(--primary)">شروط وأحكام</a> المنصة وأتعهد بأن جميع المعلومات المقدمة صحيحة ودقيقة، وأن الشهادات الأكاديمية المرفوعة أصلية وموثقة.</span>
            </label>
          </div>
        </div>
      </div>

    </form><!-- /registerForm -->

    <!-- Success Message -->
    <div id="formSuccess" style="display:none">
      <div class="card" style="padding:60px 40px;text-align:center">
        <div style="font-size:72px;margin-bottom:20px">🎉</div>
        <h2 style="font-size:26px;font-weight:900;color:var(--text-primary);margin-bottom:12px">تم إرسال طلبك بنجاح!</h2>
        <p style="color:var(--text-secondary);font-size:15px;margin-bottom:28px">تم تسجيل حسابك وقبول المؤهلات بشكل أولي. سيقوم فريق المراجعة بمطابقة المستندات وتفعيل ظهورك العام في القائمة خلال 2-3 أيام عمل.</p>
        <div style="display:flex;gap:12px;justify-content:center">
          <a href="academics-list.php" class="btn btn-outline">← تصفح الأكاديميين</a>
          <a href="academic-dashboard.php" class="btn btn-primary">لوحة التحكم →</a>
        </div>
      </div>
    </div>

    <!-- Navigation Buttons -->
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:24px;padding:0 4px" id="formNavButtons">
      <button class="btn btn-outline" id="prevBtn" onclick="StepForm.prev()" style="display:none">← السابق</button>
      <span id="stepCounter" style="font-size:13px;color:var(--text-secondary);margin:auto">الخطوة 1 من 4</span>
      <button class="btn btn-primary" id="nextBtn" onclick="StepForm.next()">التالي ←</button>
      <button class="btn btn-success" id="submitBtn" onclick="StepForm.submit()" style="display:none">✅ إرسال الطلب</button>
    </div>

  </div><!-- /register-body -->
</div>

<script src="assets/js/main.js"></script>
<script>
// Load dynamic services list
window.ACADEMICS_DATA.services = <?= json_encode($servicesJson, JSON_UNESCAPED_UNICODE) ?>;

// ---- Degree toggles ----
function toggleDegree(id) {
  const body = document.getElementById(id + 'Body');
  const arrow = document.getElementById(id + 'Arrow');
  const isOpen = body.classList.contains('open');
  body.classList.toggle('open', !isOpen);
  if (arrow) arrow.style.transform = isOpen ? '' : 'rotate(180deg)';
}
function openDegree(id) {
  const body = document.getElementById(id + 'Body');
  const arrow = document.getElementById(id + 'Arrow');
  body.classList.add('open');
  if (arrow) arrow.style.transform = 'rotate(180deg)';
}

// ---- Render services checkboxes ----
function renderServicesCheckboxes() {
  const grid = document.getElementById('servicesGrid');
  if (!grid) return;
  grid.innerHTML = ACADEMICS_DATA.services.map(s => `
    <label class="service-checkbox">
      <input type="checkbox" name="services[]" value="${s.id}" style="width:18px;height:18px;accent-color:var(--primary);flex-shrink:0"/>
      <span style="font-size:22px">${s.icon}</span>
      <span style="font-size:14px;color:var(--text-primary)">${s.name}</span>
    </label>
  `).join('');
}

// ---- Render review summary ----
function renderReviewSummary() {
  const name = document.getElementById('fullName')?.value || 'لم يتم إدخال الاسم';
  const summary = document.getElementById('reviewSummary');
  if (!summary) return;
  const checkedServices = [...document.querySelectorAll('#servicesGrid input:checked')].length;
  const degrees = [];
  if (document.getElementById('hasBachelor')?.checked) degrees.push('بكالوريوس');
  if (document.getElementById('hasMasters')?.checked) degrees.push('ماجستير');
  if (document.getElementById('hasPhd')?.checked) degrees.push('دكتوراه');

  summary.innerHTML = `
    <div style="padding:16px;background:var(--bg-main);border-radius:12px;display:flex;align-items:center;gap:14px">
      <span style="font-size:24px">👤</span>
      <div><div style="font-size:12px;color:var(--text-secondary)">الاسم الكامل</div><div style="font-weight:700;color:var(--text-primary)">${name}</div></div>
    </div>
    <div style="padding:16px;background:var(--bg-main);border-radius:12px;display:flex;align-items:center;gap:14px">
      <span style="font-size:24px">🎓</span>
      <div><div style="font-size:12px;color:var(--text-secondary)">المؤهلات</div><div style="font-weight:700;color:var(--text-primary)">${degrees.length ? degrees.join(' · ') : 'لم يتم الاختيار'}</div></div>
    </div>
    <div style="padding:16px;background:var(--bg-main);border-radius:12px;display:flex;align-items:center;gap:14px">
      <span style="font-size:24px">⚙️</span>
      <div><div style="font-size:12px;color:var(--text-secondary)">الخدمات المختارة</div><div style="font-weight:700;color:var(--text-primary)">${checkedServices} خدمة</div></div>
    </div>
  `;
}

// Override StepForm.next to build summary on step 4
const _origNext = StepForm.next.bind(StepForm);
StepForm.next = function() {
  _origNext();
  if (StepForm.currentStep === 4) renderReviewSummary();
};

// Override StepForm.submit to perform actual DB insert via AJAX fetch
StepForm.submit = function() {
  if (!this.validate()) return;
  const agree = document.getElementById('agreeTerms').checked;
  if (!agree) {
    Toast.show('يجب الموافقة على الشروط والأحكام للاستمرار', 'error');
    return;
  }

  const btn = document.getElementById('submitBtn');
  if (btn) { btn.innerHTML = '⏳ جاري الإرسال...'; btn.disabled = true; }

  const form = document.getElementById('registerForm');
  const formData = new FormData(form);

  if (document.getElementById('hasBachelor').checked) formData.append('hasBachelor', '1');
  if (document.getElementById('hasMasters').checked) formData.append('hasMasters', '1');
  if (document.getElementById('hasPhd').checked) formData.append('hasPhd', '1');

  fetch('ajax/handler.php?action=register', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      document.getElementById('formSuccess').style.display = 'block';
      document.getElementById('registerForm').style.display = 'none';
      document.getElementById('formNavButtons').style.display = 'none';
      Toast.show(data.message, 'success');
    } else {
      if (btn) { btn.innerHTML = '✅ إرسال الطلب'; btn.disabled = false; }
      Toast.show(data.message, 'error');
    }
  })
  .catch(err => {
    if (btn) { btn.innerHTML = '✅ إرسال الطلب'; btn.disabled = false; }
    Toast.show('حدث خطأ في الاتصال بالخادم.', 'error');
  });
};

document.addEventListener('DOMContentLoaded', () => {
  renderServicesCheckboxes();
  StepForm.totalSteps = 4;
  StepForm.init();
});
</script>
</body>
</html>
