﻿<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>استعادة كلمة المرور - تواصل</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/global.css">
  <style>
    .auth-bg { background: linear-gradient(135deg, var(--bg-main) 0%, rgba(79, 70, 229, 0.05) 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
    .auth-card { max-width: 450px; width: 100%; padding: 40px; margin: 0 auto; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); text-align: center; }
  </style>
</head>
<body class="auth-bg">

  <div class="card auth-card fade-up">
    
    <div style="font-size:48px;margin-bottom:16px">🔐</div>
    <h2 style="font-size:24px;font-weight:800;color:var(--text-primary);margin-bottom:8px">استعادة كلمة المرور</h2>
    <p style="color:var(--text-secondary);font-size:14px;margin-bottom:32px">أدخل بريدك الإلكتروني المسجل لدينا وسنرسل لك رابطاً مشفراً لتعيين كلمة مرور جديدة.</p>

    <form onsubmit="handleReset(event)" style="text-align:right">
      <div style="margin-bottom:24px">
        <label class="block text-sm font-bold mb-2" style="color:var(--text-primary)">البريد الإلكتروني</label>
        <input type="email" class="form-input" placeholder="ahmad@example.com" dir="ltr" required>
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%;padding:14px;font-size:16px" id="resBtn">إرسال رابط الاستعادة</button>
    </form>

    <div style="margin-top:32px;font-size:14px;color:var(--text-secondary)">
      <a href="login.php" style="color:var(--primary);font-weight:700;text-decoration:none">← العودة لتسجيل الدخول</a>
    </div>

  </div>

  <script src="assets/js/global.js"></script>
  <script>
    function handleReset(e) {
      e.preventDefault();
      const btn = document.getElementById('resBtn');
      btn.textContent = 'جاري الإرسال...';
      btn.disabled = true;
      setTimeout(() => {
        alert('تم إرسال رابط الاستعادة إلى بريدك! يرجى التحقق من صندوق الوارد.');
        window.location.href = 'login.php';
      }, 1500);
    }
  </script>
</body>
</html>

