﻿<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>مركز الإشعارات - تواصل</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/global.css">
  <style>
    .notif-card { padding: 20px; border-bottom: 1px solid var(--border-color); display: flex; gap: 16px; transition: background 0.2s; align-items: flex-start; }
    .notif-card:hover { background: var(--bg-main); }
    .notif-card.unread { background: var(--primary-light); border-right: 4px solid var(--primary); }
    .notif-icon { width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0; }
  </style>
</head>
<body style="background:var(--bg-main)">

  <!-- Minimal Nav -->
  <nav class="public-nav">
    <a href="index.php" style="font-size:24px;font-weight:900;color:var(--primary);text-decoration:none">🎓 تواصل</a>
    <div style="display:flex;gap:12px;align-items:center">
      <button class="dark-toggle" style="background:none;border:none;font-size:20px;cursor:pointer">🌙</button>
      <div style="width:1px;height:24px;background:var(--border-color)"></div>
      <div style="width:40px;height:40px;border-radius:50%;background:#4f46e5;color:white;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:16px">؟</div>
    </div>
  </nav>

  <div style="padding:40px 20px;max-width:800px;margin:0 auto">
    
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:32px" class="fade-up">
      <h1 style="font-size:32px;font-weight:900">مركز الإشعارات</h1>
      <button class="btn btn-outline" style="padding:8px 16px;font-size:13px;border-radius:40px">تحديد الكل كمقروء ✔️</button>
    </div>

    <div class="card p-0 fade-up" style="padding:0;overflow:hidden">
      
      <!-- Unread Notification -->
      <div class="notif-card unread cursor-pointer">
        <div class="notif-icon" style="background:var(--bg-card);color:var(--primary)">💰</div>
        <div style="flex-grow:1">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <h3 style="font-weight:700;font-size:16px;color:var(--text-primary)">تم تحصيل الدفعة بنجاح</h3>
            <span style="font-size:12px;color:var(--primary);font-weight:700">الآن</span>
          </div>
          <p style="font-size:14px;color:var(--text-secondary);line-height:1.6">
            تم استلام دفعتك بقيمة 450 ر.س للطلب #ORD-1045 الخاص بخدمة "التحليل الإحصائي". سيبدأ الأكاديمي بالتنفيذ فوراً.
          </p>
        </div>
      </div>

      <!-- Unread Notification -->
      <div class="notif-card unread cursor-pointer">
        <div class="notif-icon" style="background:var(--bg-card);color:var(--info)">💬</div>
        <div style="flex-grow:1">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <h3 style="font-weight:700;font-size:16px;color:var(--text-primary)">رسالة جديدة من د. محمد</h3>
            <span style="font-size:12px;color:var(--primary);font-weight:700">قبل 15 دقيقة</span>
          </div>
          <p style="font-size:14px;color:var(--text-secondary);line-height:1.6">
            "هل يمكنك إرسال المرفق بصيغة Word لنتمكن من إضافة التعليقات عليه مباشرة؟"
          </p>
        </div>
      </div>

      <!-- Read Notification -->
      <div class="notif-card cursor-pointer">
        <div class="notif-icon" style="background:rgba(16,185,129,0.1);color:var(--success)">✅</div>
        <div style="flex-grow:1">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <h3 style="font-weight:700;font-size:16px;color:var(--text-primary)">اكتمل طلبك بنجاح</h3>
            <span style="font-size:12px;color:var(--text-muted)">أمس</span>
          </div>
          <p style="font-size:14px;color:var(--text-secondary);line-height:1.6">
            تم تسليم جميع مخرجات طلب "تصميم الاستبيانات" #ORD-1042. يرجى المراجعة والتقييم قبل إغلاق الطلب رسمياً.
          </p>
        </div>
      </div>

      <!-- Read Notification -->
      <div class="notif-card cursor-pointer">
        <div class="notif-icon" style="background:rgba(245,158,11,0.1);color:var(--warning)">⏳</div>
        <div style="flex-grow:1">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <h3 style="font-weight:700;font-size:16px;color:var(--text-primary)">تغيير حالة الطلب</h3>
            <span style="font-size:12px;color:var(--text-muted)">منذ 3 أيام</span>
          </div>
          <p style="font-size:14px;color:var(--text-secondary);line-height:1.6">
            تم تحويل حالة الطلب #ORD-1049 إلى (قيد التنفيذ). الأكاديمي يعكف على العمل حالياً.
          </p>
        </div>
      </div>

    </div>

    <div style="text-align:center;margin-top:24px">
      <button class="btn btn-outline" style="border-radius:40px">عرض إشعارات أقدم ↓</button>
    </div>

  </div>

  <script src="assets/js/global.js"></script>
</body>
</html>

