<?php
/**
 * Sidebar Component - Eduroad Admin
 * 
 * تعليق: تم إضافة require_once لملف functions.php لتجنب خطأ "undefined function db()"
 */

// تضمين دوال قاعدة البيانات والمساعدات
require_once __DIR__ . '/../../config/functions.php';

// بدء الجلسة إذا لم تكن قد بدأت (للتأكد من وجود بيانات المستخدم إن لزم)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// استعلامات العد للشارات (badges)
$sb_db = db();
$sb_students_cnt = (int) $sb_db->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
$sb_academics_cnt = (int) $sb_db->query("SELECT COUNT(*) FROM academics")->fetchColumn();
$sb_featured_cnt = (int) $sb_db->query("SELECT COUNT(*) FROM featured_academics")->fetchColumn();
$sb_orders_cnt = (int) $sb_db->query("SELECT COUNT(*) FROM orders WHERE status = 'new'")->fetchColumn();
$sb_colleges_cnt = 0;
try {
    $sb_colleges_cnt = (int) $sb_db->query("SELECT COUNT(*) FROM colleges")->fetchColumn();
} catch (Exception $e) {}
?>
<!-- ============================================
     Sidebar Component - Eduroad Admin
     ============================================ -->
<aside class="sidebar" id="sidebar">

  <!-- Logo -->
  <div class="sidebar-logo">
    <div class="logo-icon" style="background:none;box-shadow:none;overflow:hidden;border-radius:10px"><img src="../../image/eduroad_logo.png" alt="Eduroad" style="width:100%;height:100%;object-fit:contain" /></div>
    <span class="logo-text">Eduroad Admin</span>
    <button class="sidebar-mobile-close" id="sidebarMobileClose" title="إغلاق القائمة">✕</button>
  </div>

  <!-- Navigation -->
  <nav class="sidebar-nav">

    <!-- Main -->
    <p class="nav-section-title">القائمة الرئيسية</p>

    <a href="../pages/dashboard.php" class="nav-item" id="nav-dashboard">
      <span class="nav-icon">📊</span>
      <span class="nav-label">الرئيسية</span>
    </a>

    <!-- Users -->
    <p class="nav-section-title">إدارة المستخدمين</p>

    <a href="../pages/users.php" class="nav-item" id="nav-users">
      <span class="nav-icon">👥</span>
      <span class="nav-label">الطلاب</span>
      <span class="nav-badge"><?= number_format($sb_students_cnt) ?></span>
    </a>

    <a href="../pages/academics.php" class="nav-item" id="nav-academics">
      <span class="nav-icon">🎓</span>
      <span class="nav-label">الأكاديميون</span>
      <span class="nav-badge"><?= number_format($sb_academics_cnt) ?></span>
    </a>

     <a href="../pages/featured-academics.php" class="nav-item" id="nav-featured-academics">
      <span class="nav-icon" style="color:#f59e0b">⭐</span>
      <span class="nav-label">الأكاديميون المتميزون</span>
      <span class="nav-badge" style="background:linear-gradient(135deg,#f59e0b,#d97706)"><?= number_format($sb_featured_cnt) ?></span>
    </a>

    <a href="../pages/colleges.php" class="nav-item" id="nav-colleges">
      <span class="nav-icon">🏛️</span>
      <span class="nav-label">الكليات والتخصصات</span>
      <?php if ($sb_colleges_cnt > 0): ?>
        <span class="nav-badge"><?= number_format($sb_colleges_cnt) ?></span>
      <?php endif; ?>
    </a>

    <!-- Operations -->
    <p class="nav-section-title">العمليات</p>

    <a href="../pages/services.php" class="nav-item" id="nav-services">
      <span class="nav-icon">⚙️</span>
      <span class="nav-label">الخدمات</span>
    </a>

    <a href="../pages/packages.php" class="nav-item" id="nav-packages">
      <span class="nav-icon">💎</span>
      <span class="nav-label">الباقات</span>
    </a>

    <a href="../pages/orders.php" class="nav-item" id="nav-orders">
      <span class="nav-icon">📋</span>
      <span class="nav-label">الطلبات</span>
      <?php if ($sb_orders_cnt > 0): ?>
        <span class="nav-badge" style="background:#ef4444"><?= $sb_orders_cnt ?></span>
      <?php endif; ?>
    </a>

    <!-- Finance -->
    <p class="nav-section-title">المالية والتقارير</p>

    <a href="../pages/payments.php" class="nav-item" id="nav-payments">
      <span class="nav-icon">💰</span>
      <span class="nav-label">المدفوعات</span>
    </a>

    <a href="../pages/payout-policy.php" class="nav-item" id="nav-payout-policy">
      <span class="nav-icon">📜</span>
      <span class="nav-label">سياسة دفع الأكاديميين</span>
    </a>

    <a href="../pages/reports.php" class="nav-item" id="nav-reports">
      <span class="nav-icon">📈</span>
      <span class="nav-label">التقارير</span>
    </a>

    <!-- System -->
    <p class="nav-section-title">النظام</p>

    <a href="../pages/support.php" class="nav-item" id="nav-support">
      <span class="nav-icon">💬</span>
      <span class="nav-label">الدعم الفني والشكاوى</span>
      <?php
      require_once __DIR__ . '/../../config/support_functions.php';
      $sb_support_cnt = countUnreadSupportForAdmin('student') + countUnreadSupportForAdmin('academic');
      if ($sb_support_cnt > 0): ?>
        <span class="nav-badge" style="background:#ef4444"><?= $sb_support_cnt ?></span>
      <?php endif; ?>
    </a>

    <a href="../pages/settings.php" class="nav-item" id="nav-settings">
      <span class="nav-icon">🔧</span>
      <span class="nav-label">الإعدادات</span>
    </a>

    <a href="../pages/policies.php" class="nav-item" id="nav-policies">
      <span class="nav-icon">📜</span>
      <span class="nav-label">السياسات والخصوصية</span>
    </a>

  </nav>

  <!-- Footer -->
  <div class="sidebar-footer">
    <a href="<?= rootUrl() ?>/logout.php" class="nav-item">
      <span class="nav-icon">🚪</span>
      <span class="nav-label">تسجيل الخروج</span>
    </a>
  </div>

</aside>