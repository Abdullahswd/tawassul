import os
import zipfile

zip_filename = 'eduroad_production.zip'

# If previous zip exists, remove it
if os.path.exists(zip_filename):
    os.remove(zip_filename)

# Excluded folders / files
exclude_dirs = {'.git', '.gemini', 'node_modules', '.idea', '.vscode'}
exclude_files = {zip_filename, 'tawassul_production_ready.zip'}

added_files_count = 0
total_size = 0

print(f"Creating {zip_filename}...")

with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        # Filter out directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if file in exclude_files:
                continue
            if file.endswith('.zip'):
                continue
            
            full_path = os.path.join(root, file)
            # Relative path inside the zip archive
            arcname = os.path.relpath(full_path, '.')
            
            # Avoid leading .\ in arcname
            arcname = arcname.replace('\\', '/')
            if arcname.startswith('./'):
                arcname = arcname[2:]
            
            zipf.write(full_path, arcname)
            added_files_count += 1
            total_size += os.path.getsize(full_path)

zip_size_mb = os.path.getsize(zip_filename) / (1024 * 1024)
print(f"ZIP successfully created: {zip_filename}")
print(f"Total files included: {added_files_count}")
print(f"Uncompressed size: {total_size / (1024 * 1024):.2f} MB")
print(f"Compressed archive size: {zip_size_mb:.2f} MB")
